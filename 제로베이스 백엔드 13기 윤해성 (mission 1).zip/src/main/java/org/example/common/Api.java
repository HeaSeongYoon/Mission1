package org.example.common;



public class Api {
    public static final String BASE_URL = "http://openapi.seoul.go.kr:8088";
    public static final String KEY = "5a6c6e62556a6f6833336c496f4950";
    public static final String TYPE = "json";
    public static final String SERVICE = "TbPubWifiInfo";

}

